﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;

class Program
{
    static void Main()
    {
        // --- INICJALIZACJA ---
        // Ustawiamy domyślne hasło, aby system zawsze miał co sprawdzać
        string password = "admin";
        List<string> Users = new List<string> { "Admin", "Guest" };
        List<string> Admins = new List<string> { "Admin" };
        string aktualUser = "Admin";
        bool isAdmin = true;

        // --- EFEKT ŁADOWANIA ---
        Console.CursorVisible = false;
        for (int i = 0; i <= 100; i += 2) // Skok co 2, żeby było dynamicznie
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write($"\r{i}% ładowania Systemu...");
            Thread.Sleep(20);
        }
        Console.CursorVisible = true;
        Console.Clear();

        Console.ResetColor();
        Console.WriteLine("Jak masz na imię:");
        string imie = Console.ReadLine();
        Console.WriteLine($"Witaj {imie}! System gotowy.");
        Thread.Sleep(800);
        Console.Clear();

        // --- GŁÓWNA PĘTLA ---
        while (true)
        {
            // Aktualizacja statusu admina dla aktualnego użytkownika
            isAdmin = Admins.Contains(aktualUser);

            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($"\n>>> {aktualUser} (Admin: {isAdmin}) $:: ");
            Console.ResetColor();

            string cmd = Console.ReadLine()?.Trim();
            if (string.IsNullOrEmpty(cmd)) continue;

            // --- KOMENDY ---

            if (cmd.Equals("help", StringComparison.OrdinalIgnoreCase))
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("\n------- DOSTĘPNE KOMENDY -------");
                Console.WriteLine("clear    -- Czyści konsolę");
                Console.WriteLine("dir      -- Zawartość folderu");
                Console.WriteLine("UserNew  -- Tworzy użytkownika (Wymaga Admina)");
                Console.WriteLine("getadmin -- Nadaje uprawnienia admina");
                Console.WriteLine("Setpass  -- Zmienia hasło systemowe");
                Console.WriteLine("login    -- Zmienia użytkownika");
                Console.WriteLine("admin?   -- Sprawdza status uprawnień");
                Console.WriteLine("shutdown -- Zamyka system (komputer!)");
                Console.WriteLine("exit     -- Wyjście z programu");
                Console.WriteLine("--------------------------------");
                Console.ResetColor();
            }
            else if (cmd == "clear")
            {
                Console.Clear();
            }
            else if (cmd == "admin?")
            {
                if (isAdmin) Console.WriteLine($"Użytkownik {aktualUser} POSIADA uprawnienia.");
                else Console.WriteLine($"Użytkownik {aktualUser} NIE POSIADA uprawnień.");
            }
            else if (cmd == "dir")
            {
                try
                {
                    string[] entries = Directory.GetFileSystemEntries(Directory.GetCurrentDirectory());
                    foreach (var entry in entries)
                    {
                        string name = Path.GetFileName(entry);
                        bool isDir = Directory.Exists(entry);
                        Console.WriteLine(isDir ? $"[DIR] {name}" : $"      {name}");
                    }
                }
                catch (Exception ex) { Console.WriteLine("Błąd dir: " + ex.Message); }
            }
            else if (cmd == "UserNew")
            {
                if (isAdmin)
                {
                    Console.Write("Nazwa nowego użytkownika: ");
                    string newUser = Console.ReadLine();
                    if (!string.IsNullOrWhiteSpace(newUser) && !Users.Contains(newUser))
                    {
                        Users.Add(newUser);
                        Console.WriteLine($"Dodano użytkownika {newUser}.");
                    }
                    else Console.WriteLine("Błąd: Niepoprawna nazwa lub użytkownik już istnieje.");
                }
                else Console.WriteLine("Błąd: Brak uprawnień administratora.");
            }
            else if (cmd == "Setpass")
            {
                if (isAdmin)
                {
                    Console.Write("Podaj stare hasło: ");
                    if (Console.ReadLine() == password)
                    {
                        Console.Write("Podaj nowe hasło: ");
                        password = Console.ReadLine();
                        Console.WriteLine("Hasło zostało zmienione.");
                    }
                    else Console.WriteLine("Błąd: Nieprawidłowe stare hasło.");
                }
                else Console.WriteLine("Błąd: Tylko Admin może zmieniać hasło.");
            }
            else if (cmd == "login")
            {
                Console.Write("Zaloguj na: ");
                string targetUser = Console.ReadLine();

                if (Users.Contains(targetUser))
                {
                    // Jeśli logujemy się na konto, które jest na liście Admins
                    if (Admins.Contains(targetUser))
                    {
                        Console.Write($"Podaj hasło dla {targetUser}: ");
                        string inputPass = Console.ReadLine();
                        if (inputPass == password)
                        {
                            aktualUser = targetUser;
                            Console.WriteLine($"Zalogowano pomyślnie jako {aktualUser}.");
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("BŁĘDNE HASŁO. Logowanie przerwane.");
                            Console.ResetColor();
                        }
                    }
                    else
                    {
                        aktualUser = targetUser;
                        Console.WriteLine($"Zalogowano jako {aktualUser}.");
                    }
                }
                else Console.WriteLine("Użytkownik nie istnieje.");
            }
            else if (cmd == "getadmin")
            {
                if (isAdmin)
                {
                    Console.Write("Podaj nazwę użytkownika, któremu chcesz dać uprawnienia: ");
                    string target = Console.ReadLine();
                    if (Users.Contains(target))
                    {
                        if (!Admins.Contains(target)) Admins.Add(target);
                        Console.WriteLine($"Użytkownik {target} otrzymał uprawnienia Admina.");
                    }
                    else Console.WriteLine("Nie ma takiego użytkownika.");
                }
                else Console.WriteLine("Błąd: Brak uprawnień do nadawania rangi Admina.");
            }
            else if (cmd == "exit")
            {
                break;
            }
            else if (cmd.Equals("shutdown", StringComparison.OrdinalIgnoreCase))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("POTWIERDŹ HASŁO ADMINA, ABY WYŁĄCZYĆ KOMPUTER: ");
                string input = Console.ReadLine();

                if (input == password)
                {
                    Console.WriteLine("ZAMYKANIE SYSTEMU...");
                    Thread.Sleep(1000);
                    Process.Start("shutdown", "/s /t 10");
                    break;
                }
                else Console.WriteLine("Odmowa dostępu: Niepoprawne hasło.");
                Console.ResetColor();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Nieznana komenda. Wpisz 'help' aby zobaczyć listę.");
                Console.ResetColor();
            }
        }
    }
}